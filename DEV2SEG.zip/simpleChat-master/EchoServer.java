// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.IOException;

import common.ChatIF;
import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */
public class EchoServer extends AbstractServer 
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  ChatIF serverUI;
  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the echo server.
   *
   * @param port The port number to connect on.
   */
  public EchoServer(int port) 
  {
    super(port);
  }

  
  //Instance methods ************************************************
  
  /**
   * This method handles any messages received from the client.
   *
   * @param msg The message received from the client.
   * @param client The connection from which the message originated.
   */
  public void handleMessageFromClient
    (Object msg, ConnectionToClient client)
  {
	  System.out.println("Message received: " + msg + " from " + client);
	  this.sendToAllClients(msg);
	 
  }
  
  /**
   * This method handles all data coming from the UI            
   *
   * @param message The message from the UI.    
   */
  public void handleMessageFromServerUI(String msg)
  {
	  if(((String) msg).startsWith("#")) {
        handleCommand((String) msg);
      }
      else
    	  this.sendToAllClients("SERVER MSG>" + msg);
      
  }
 
  /**
   * this method execute command from client start with "#"
   * @param message
 * @throws IOException 
   */
  private void handleCommand(String cmd) {
    if(cmd.equals("#quit")) {
      serverUI.display("the server will quit");
      quit();
    
    }
    else if (cmd.equals("#stop")) {
      stopListening();
    }
    else if(cmd.equals("#close")) {
      this.serverClosed();
      serverUI.display("the server will close SORRY!");
      
      }
    else if(cmd.equals("#setport")) {
      if(!this.isListening()) {
      
        int a =  Integer.parseInt(cmd);
        this.setPort(a);
      }
      else
    	  serverUI.display("Le server n'est pas d�connect�!");
      
    
  }
    else if(cmd.equals("#getport")) {
        this.getPort();
    }
    
    else if(cmd.equals("#start")) {
      if(!this.isListening()) {
        this.serverStarted();
      }
      else 
    	  serverUI.display("Le server n'est pas arr�t�!");
    }
    

  }

  
  
    
  /**
   * This method overrides the one in the superclass.  Called
   * when the server starts listening for connections.
   */
  protected void serverStarted()
  {
    System.out.println
      ("Server listening for connections on port " + getPort());
  }
  
  /**
   * This method overrides the one in the superclass.  Called
   * when the server stops listening for connections.
   */
  protected void serverStopped()
  {
    System.out.println
      ("Server has stopped listening for connections.");
  }
  
  //Class methods ***************************************************
  

  /**
   * Implementation of the hook method called each time a new client connection is
   * accepted. The default implementation does nothing.
   * @param client the connection connected to the client.
   */
  @Override
  protected void clientConnected(ConnectionToClient client) {
	  System.out.println("the client "+ client+" is connected");
  }

  /**
   * Implementation of the hook method called each time an exception is thrown in a
   * ConnectionToClient thread.
   * The method may be overridden by subclasses but should remains
   * synchronized.
   *
   * @param client the client that raised the exception.
   * @param Throwable the exception thrown.
   */
  
  synchronized protected void clientException(ConnectionToClient client, Throwable exception) {
	  System.out.println("A client is disconnected");
	  
  }
  /**
   * This method terminates the client.
   */
  public void quit()
  {
    serverClosed();
  }
  
}
//End of EchoServer class
